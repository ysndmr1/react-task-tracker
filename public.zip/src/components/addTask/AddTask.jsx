const AddTask = () => {
  return <div>AddTask</div>;
};

export default AddTask;
